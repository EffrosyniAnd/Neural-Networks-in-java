import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Math;
import java.util.Arrays;
import java.util.Random;

public class KM {
	public static int M;// Number of Cluster groups
	public static int maxIterations = 10000; // Max epochs
	public static int similarityCounter;// This is a counter that increments once our centroids remain the same.If this
										// happens for 2 consecutive times we accept and return those centroids as our
										// finalCentroids.
	public static int iterationsCount;// If our centroids keep adjusting and the similarityCounter stays at 0, we will
										// terminate at iterationsCount = maxIterations(Basically our epochs).
	public static double[][] trainingData = new double[900][2];// This table contains the data(X1,X2) that we read from
																// our CSV
	public static double[][] centroids;// K centoids with x1,x2 values as coordinates in a 2d system
	public static int[] tests = { 2, 3, 4, 5, 6, 7, 10 }; // This table contains our test Clusters assigned to variable
															// M.
	public static double[][] totalDispersions = new double[tests.length][2];// This table is required in order to plot
																			// the "M/Dispersion" diagram.

	// Accesory variables required for our implementation.As we compare the
	// dispersion between our examples we save the data that corresponds to the best
	// dispersion found.
	// Afterwards we plot this data, as we want to plot the example with the best
	// dispersion.
	public static double[][] cpyCentroids;
	public static int[][] clusters;
	public static int[] clusterCount;

	public static double[][] bestCentroids;
	public static int[][] bestClusters;
	public static int[] bestClusterCount;

	public static double[][] finalCentroids;
	public static int[][] finalClusters;
	public static int[] finalClusterCount;

	/**
	 * @main
	 * 
	 *       This function runs the Kmeans algorithm 5 times for each example of our
	 *       tests table.It proceeds to plot the example that was found to have the
	 *       best Dispersion. Afterwards it plots a graph that shows the relation
	 *       between the Dispersion and the variable M that represents the clusters.
	 */
	public static void main(String[] args) throws IOException {

		double bestDispersion;// best dispersion = min dispersion
		double tempDispersion;
		double finalDispersion = Double.MAX_VALUE;

		readFile(trainingData);

		// Kmeans Algorithm
		System.out.println("RUNNING KM\n");
		// Here we run the Kmeans algorithm 5 times for every different value of 'M'
		// from our tests table.
		for (int m = 0; m < tests.length; m++) {
			M = tests[m];
			bestDispersion = Double.MAX_VALUE;
			resetVariables();// Here we reset the variables required for each run for every 'M'.
			for (int i = 0; i < 5; i++) {
				iterationsCount = 0;
				similarityCounter = 0;
				generateCentroids(centroids);// Here we generate our starting Centroids.
				// This while loop ensures we will either stop at our desired maximum number of
				// epochs or once there is no change in the weights of the centroids.
				while (checkIterations()) {

					runKM(trainingData, centroids);
				}
				// Here we proceed to find the best(min) dispersionError between our runs.We
				// will keep this and compare it between the rest of the lowest dispersions
				// found for the other values of 'M'.
				tempDispersion = findDispersionError();
				if (tempDispersion < bestDispersion) {
					bestDispersion = tempDispersion;
					bestClusters = deepCopy(clusters);
					bestClusterCount = Arrays.copyOfRange(clusterCount, 0, clusterCount.length);
					bestCentroids = deepCopy(centroids);
				}
			}
			// In the table totalDispersions we save the dispersionsFound in order to later
			// on plot the correlation between the dispersionError and the number of
			// clusters 'M'.
			totalDispersions[m][0] = M;
			totalDispersions[m][1] = bestDispersion;

			// As we explained in an earlier comment we save the lowest dispersion found in
			// order to plot it.The variables below correspond to the variable 'M' for which
			// the finalDispersion or lowest Dispersion was found.
			if (bestDispersion < finalDispersion) {

				finalClusters = new int[M][900];
				finalCentroids = new double[M][2];
				finalClusterCount = new int[M];
				finalClusters = deepCopy(bestClusters);
				finalCentroids = deepCopy(bestCentroids);
				finalClusterCount = Arrays.copyOfRange(bestClusterCount, 0, bestClusterCount.length);
				finalDispersion = bestDispersion;
			}
		}

		// This is our 1st Plot that shows our clusters and how they have divided our
		// trainingData.
		clusterPlot plotObj = new clusterPlot(trainingData, finalCentroids, finalClusters, finalClusterCount);
		plotObj.setVisible(true);
		plotObj.setResizable(false);
		System.out.println("Stopped at: " + iterationsCount + " iterations(epochs).");
		print(tests, totalDispersions);
		System.out.println("The lowest dispersion found is: [" + finalDispersion + "]");

		// This is our 2nd Plot that shows the relation between the dispersion and the
		// variable 'M'.
		dispersionPlot dispersionsPlot = new dispersionPlot(totalDispersions);
		dispersionsPlot.setVisible(true);
		dispersionsPlot.setResizable(false);
	}

	/**
	 * @resetVariables
	 * 
	 *                 This function ensures that the variables required for the KM
	 *                 algorithm will be reset for each unique value of variable
	 *                 'M'.
	 * 
	 */
	public static void resetVariables() {
		bestCentroids = new double[M][2];
		cpyCentroids = new double[M][2];
		clusters = new int[M][900];
		clusterCount = new int[M];
		centroids = new double[M][2];
		bestClusters = new int[M][900];
		bestClusterCount = new int[M];
	}

	/**
	 * @runKM This function implements the KMeans algorithm. It assigns each data
	 *        point to the closest cluster (centroid). Furthermore it computes and
	 *        adjusts the centroids for the clusters by taking the average of the
	 *        all data points that belong to each cluster.
	 * 
	 */
	public static void runKM(double[][] trainingData, double[][] centroids) {
		findMinEuclidDistance(trainingData);
		adjustCentroids(centroids);
	}

	/**
	 * @readFile
	 * 
	 *           This function simply reads our CSV data and saves it in our table
	 *           trainingData.
	 * 
	 */
	public static void readFile(double[][] trainingData2) throws IOException {
		// Remember to read from the correct path!!
		BufferedReader csvReader = new BufferedReader(
				new FileReader("C:/Users/Panteloueyy/eclipse-workspace/KM/groupData.csv"));
		for (int i = 0; i < 900; i++) {
			String row;
			row = csvReader.readLine();
			String[] readcsv = row.split(",");
			// do something with the data
			trainingData2[i][0] = Double.parseDouble(readcsv[0]);
			trainingData2[i][1] = Double.parseDouble(readcsv[1]);
		}
		csvReader.close();
	}

	/**
	 * @findMinEuclidDistance
	 * 
	 *                        This function finds the minEuclidean distance of each
	 *                        point in the trainingData table. The points are
	 *                        assigned to the closest centroid.
	 */
	public static void findMinEuclidDistance(double[][] trainingData) {
		// distance: actual distance
		// temp: temporary min distance
		// cluster: keep the cluster/team we are working on

		for (int i = 0; i < M; i++) {
			clusterCount[i] = 0;
		}

		double distance, temp;
		int winner;
		for (int i = 0; i < trainingData.length; i++) {
			// Euclidean distance for the first centroid.
			distance = Math.sqrt(Math.pow(Math.abs((trainingData[i][0] - centroids[0][0])), 2)
					+ Math.pow(Math.abs((trainingData[i][1] - centroids[0][1])), 2));
			;
			winner = 0;
			for (int j = 1; j < M; j++) {
				// Euclidean Distance for the rest of the centroids.
				temp = Math.sqrt(Math.pow(Math.abs((trainingData[i][0] - centroids[j][0])), 2)
						+ Math.pow(Math.abs((trainingData[i][1] - centroids[j][1])), 2));
				// Save the lowest distance found.
				if (temp < distance) {
					distance = temp;

					winner = j;
				}
			}
			// Connect the trainingData points to a centroid(winner).
			clusters[winner][clusterCount[winner]] = i;
			clusterCount[winner]++;
		}
	}

	/**
	 * @adjustCentroids
	 * 
	 *                  This function computes and adjusts the centroids for the
	 *                  clusters by taking the average of the all data points that
	 *                  belong to each cluster.
	 */
	public static void adjustCentroids(double[][] centroids) {
		double newX1, newX2;
		for (int i = 0; i < clusters.length; i++) {
			newX1 = 0.0;
			newX2 = 0.0;
			for (int j = 0; j < clusterCount[i]; j++) {
				newX1 += trainingData[clusters[i][j]][0];
				newX2 += trainingData[clusters[i][j]][1];
			}
			if (clusterCount[i] == 0) {
				centroids[i][0] = 0.0;
				centroids[i][1] = 0.0;
			} else {
				newX1 = newX1 / (double) clusterCount[i];
				newX2 = newX2 / (double) clusterCount[i];
				centroids[i][0] = newX1;
				centroids[i][1] = newX2;
			}

		}
	}

	/**
	 * @generateCentroids
	 * 
	 *                    This function generates the starting centroids.They are
	 *                    picked among our initial dataset in a random fashion.
	 *
	 */
	public static void generateCentroids(double[][] centroids) {
		// We must either pick our starting neuron-centroids from our dataset OR
		// generate the centroids ensuring that their X1,X2 values are between the
		// lowest and highest value found in our trainingData set.
		// The algorithm could work with totally random starting neuron-centroids, alas
		// it could be slower.
		Random rand = new Random();
		for (int i = 0; i < M; i++) {
			int r = rand.nextInt(600);
			// Neuron X1,X2
			centroids[i][0] = trainingData[r][0];
			centroids[i][1] = trainingData[r][1];
		}
	}

	/**
	 * @checkIterations
	 * 
	 *                  This function ensures that our algorithm will stop if our
	 *                  centroids stay the same for 2 consecutive times or if we
	 *                  reach the desired maximum number of epochs(maxIterations).
	 *
	 */
	public static boolean checkIterations() {
		if (Arrays.deepEquals(cpyCentroids, centroids)) {
			similarityCounter++;
		} else {
			similarityCounter = 0;
			cpyCentroids = deepCopy(centroids);
		}
		if (similarityCounter > 0 || iterationsCount == maxIterations) {
			return false;
		}
		iterationsCount++;
		return true;
	}

	/**
	 * @findDispersionError
	 * 
	 *                      This function returns the dispersionError.
	 *
	 */
	public static double findDispersionError() {
		double distance;
		distance = 0.0;

		for (int i = 0; i < M; i++) {
			for (int j = 0; j < clusterCount[i]; j++) {
				distance += Math.sqrt(Math.pow(Math.abs(trainingData[clusters[i][j]][0] - centroids[i][0]), 2)
						+ Math.pow(Math.abs(trainingData[clusters[i][j]][1] - centroids[i][1]), 2));
			}
		}
		return distance;
	}

	/**
	 * @print
	 * 
	 *        This is a print function for our Dispersion/M correlation.
	 *
	 */
	public static void print(int[] tests, double[][] table) {
		for (int i = 0; i < 7; i++) {
			System.out.println("Dispersion of: [" + table[i][1] + "] with M=" + tests[i] + ".");
		}
	}

	/**
	 * @deepCopy
	 * 
	 *           This function makes a deep copy of a 2d-double array.
	 *
	 */
	public static double[][] deepCopy(double[][] original) {

		final double[][] result = new double[original.length][];
		for (int i = 0; i < original.length; i++) {
			result[i] = Arrays.copyOf(original[i], original[i].length);
		}
		return result;
	}

	/**
	 * @deepCopy
	 * 
	 *           This function makes a deep copy of a 2d-int array.
	 *
	 */
	public static int[][] deepCopy(int[][] original) {

		final int[][] result = new int[original.length][];
		for (int i = 0; i < original.length; i++) {
			result[i] = Arrays.copyOf(original[i], original[i].length);
		}
		return result;
	}

	/**
	 * @Getters
	 * 
	 *          These are our getter functions.The data below is needed in the
	 *          clusterPlot-dispersionPlot classes.They will be used to create our
	 *          graphs.
	 *
	 */
	public static double[][] getTrainingData() {
		return trainingData;
	}

	public static double[][] getCentroids() {
		return centroids;
	}

	public static int[][] getClusters() {
		return clusters;
	}

	public static int[] getClusterCount() {
		return clusterCount;
	}

	public static double[][] getDispersionData() {
		return totalDispersions;
	}

}
