import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class create {
    public static void main(String[] args) throws IOException {
		FileWriter xWriter = new FileWriter(new File("src","xWriter.csv"));
		FileWriter yWriter = new FileWriter(new File("src","yWriter.csv"));
        float max=1;
        float min=-1;
        for (int i=0;i<3000;i++){
            float x1=(float) (min +Math.random()*(max-min));
            float x2=(float)(min +Math.random()*(max-min));
            double error=(Math.random()*100);
            if(x1*x1+x2*x2<0.25){
                if(error<10){
                    xWriter.append(x1+","+x2+","+"4"+"\n");
                   
                }
                else{
                    xWriter.append(x1+","+x2+","+"1"+"\n");
                }
            }
            else if(x1<=-0.4&&x2<=-0.4){
                if(error<10){
                    xWriter.append(x1+","+x2+","+"4"+"\n");
                }
                else{
                    xWriter.append(x1+","+x2+","+"2"+"\n");
                }
            }
            else if(x1>=0.4&&x2>=0.4){
                if(error<10){
                    xWriter.append(x1+","+x2+","+"4"+"\n");
                }
                else{
                    xWriter.append(x1+","+x2+","+"2"+"\n");
                }
            }
            else if(x1<=-0.4&&x2>=0.4){
                if(error<10){
                    xWriter.append(x1+","+x2+","+"4"+"\n");
                }
                else{
                    xWriter.append(x1+","+x2+","+"3"+"\n");
                }
            }
            else if(x1>=0.4&&x2<=-0.4){
                if(error<10){
                    xWriter.append(x1+","+x2+","+"4"+"\n");
                }
                else{
                    xWriter.append(x1+","+x2+","+"3"+"\n");
                }
            }
            else{
                xWriter.append(x1+","+x2+","+"4"+"\n");
            }
        }
        xWriter.flush();
        xWriter.close(); 
        ////////////////////////////////////////////////////////////////////
        for (int i=0;i<3000;i++){
            float x1=(float) (min +Math.random()*(max-min));
            float x2=(float)(min +Math.random()*(max-min));
            if(x1*x1+x2*x2<0.25){
                yWriter.append(x1+","+x2+","+"1"+"\n");
            }
            else if(x1<=-0.4&&x2<=-0.4){
                yWriter.append(x1+","+x2+","+"2"+"\n");
            }
            else if(x1>=0.4&&x2>=0.4){
                yWriter.append(x1+","+x2+","+"2"+"\n");
            }
            else if(x1<=-0.4&&x2>=0.4){
                yWriter.append(x1+","+x2+","+"3"+"\n");
            }
            else if(x1>=0.4&&x2<=-0.4){
                yWriter.append(x1+","+x2+","+"3"+"\n");
            }
            else{
                yWriter.append(x1+","+x2+","+"4"+"\n");
            }
        }
        yWriter.flush();
        yWriter.close(); 
    }
}
