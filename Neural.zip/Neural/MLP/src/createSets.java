import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
//import java.util.*;

public class createSets {
	
    public static void main(String[] args) throws IOException {
		FileWriter trainingWriter = new FileWriter(new File("trainingWriter.csv"));//File for training set
		FileWriter controlWriter = new FileWriter(new File("controlWriter.csv"));//File for control set
        float max=1;//[-1,1]
        float min=-1;//[-1,1]
		
		//Create training set
		for (int i=0;i<4000;i++){
            double error=(Math.random()*100);
			float x1=(float) (min +Math.random()*(max-min)); //random between [-1,1]
			float x2=(float)(min +Math.random()*(max-min)); //random between [-1,1]
            
			if( Math.pow((x1-5),2) + Math.pow((x2-5),2) < 0.16){ //category c1
                if(error<10){
                    trainingWriter.append(x1+","+x2+","+"3"+"\n");
                   
                }
                else{
                    trainingWriter.append(x1+","+x2+","+"1"+"\n");
                }
            }
            else if( Math.pow((x1+5),2) + Math.pow((x2+5),2)<0.16){  //category c1
                if(error<10){
                    trainingWriter.append(x1+","+x2+","+"4"+"\n");
                }
                else{
                    trainingWriter.append(x1+","+x2+","+"1"+"\n");
                }
            }
            else if( Math.pow((x1-5),2) + Math.pow((x2+5),2) <0.16){ //category c2
                if(error<10){
                    trainingWriter.append(x1+","+x2+","+"3"+"\n");
                }
                else{
                    trainingWriter.append(x1+","+x2+","+"2"+"\n");
                }
            }
            else if( Math.pow((x1+5),2) + Math.pow((x2-5),2) <0.16){ //category c2
                if(error<10){
                    trainingWriter.append(x1+","+x2+","+"4"+"\n");
                }
                else{
                    trainingWriter.append(x1+","+x2+","+"2"+"\n");
                }
            }
			
            else if(x1>=0 && x2>=0 || x1<=0 && x2<=0 ){ //category c3
                if(error<10){
                    trainingWriter.append(x1+","+x2+","+"4"+"\n");
                }
                else{
                    trainingWriter.append(x1+","+x2+","+"3"+"\n");
                }
            }
            else{ //category c4
                trainingWriter.append(x1+","+x2+","+"4"+"\n");
            }
        }
        trainingWriter.flush();
        trainingWriter.close(); 
		
        //Create control set
        for (int i=0;i<4000;i++){
			float x1=(float) (min +Math.random()*(max-min)); //random between [-1,1]
			float x2=(float)(min +Math.random()*(max-min)); //random between [-1,1]
            
			
            if( Math.pow((x1-5),2) + Math.pow((x2-5),2)<0.16){
                controlWriter.append(x1+","+x2+","+"1"+"\n");
            }
            else if( Math.pow((x1+5),2) + Math.pow((x2+5),2)<0.16){
                controlWriter.append(x1+","+x2+","+"1"+"\n");
            }
            else if( Math.pow((x1-5),2) + Math.pow((x2+5),2) <0.16){
                controlWriter.append(x1+","+x2+","+"2"+"\n");
            }
            else if( Math.pow((x1+5),2) + Math.pow((x2-5),2)<0.16){
                controlWriter.append(x1+","+x2+","+"2"+"\n");
            }
            else if(x1>=0 && x2>=0 || x1>=0 && x2>=0){
                controlWriter.append(x1+","+x2+","+"3"+"\n");
            }
            else{
                controlWriter.append(x1+","+x2+","+"4"+"\n");
            }
        }
        controlWriter.flush();
        controlWriter.close(); 
    }
}
