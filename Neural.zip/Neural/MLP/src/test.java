import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

public class test(){
	/**
	 * @test
	 * 
	 *                 This function tests the training that we did previously
	 *                 We consider each output of the "final" layer and accept the one
	 *                 with the maximum value.If that output belongs to the "exit" that
	 *                 was expected to be in the first place, we increment our correct counter.
	 *                 Else proceed with the next input.
	 *                 At the end of the function we calculate the '%' average accuracy
	 *                 of our training.       
	 * 
	 */
	private static double[] arrayOut1;
	private static double[] arrayOut2;
	private static double[] fwpOutput;
	
	public static void test() {
		//The output of each layer
		arrayOut1 = new double[H1];
		arrayOut2 = new double[H2];
		fwpOutput = new double[K + 1];

		int correct = 0;//Hit-ratio counter
		for (int i = 0; i < elements; i++) {
			//start by filling each output array with 0 values
			Arrays.fill(arrayOut1, 0, arrayOut1.length, 0.0);
			Arrays.fill(arrayOut2, 0, arrayOut2.length, 0.0);
			Arrays.fill(fwpOutput, 0, fwpOutput.length, 0.0);
			int temp = 0;//A temp value to find the maximum output
			forwardPass(testData[i], arrayOut1, arrayOut2, fwpOutput);//forwardpass
			//Get the maximum output value
			double max = fwpOutput[0];
			for (int j = 1; j < K; j++) {
				if (max < fwpOutput[j]) {
					max = fwpOutput[j];
					temp = j;
				}
			}

			if ((temp + 1) == fwpOutput[K]) {
				tempCorrectElements[i] = true;
				correct++;
			} else {
				tempCorrectElements[i] = false;
			}
		}

		//Calculate the training Accuracy
		avgPercentage += correct / (double) elements;
	}
	
}